<footer class="row bg-light py-4 mt-auto">
    <div class="col"> Footer content here... </div>
</footer>