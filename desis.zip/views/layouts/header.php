<header class="header" id="header">
        <a class="btn open-menu" href="#" role="button" style="background-color: #92dde4;color: #fff;">
                <i class="fas fa-align-left"></i>
        </a>
</header>